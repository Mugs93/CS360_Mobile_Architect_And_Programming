package com.zybooks.cs360_mugford_coty_weighttrackerapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

public class HomeFragment extends Fragment {
    private WeightTrackerDatabase database;
    private SharedPreferences sharedPreferences;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_home, container, false); // Inflate the fragment layout

        RecyclerView recyclerView = rootView.findViewById(R.id.weight_grid);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        database = new WeightTrackerDatabase(getContext());
        RecyclerAdapter adapter = new RecyclerAdapter(database);
        recyclerView.setAdapter(adapter);

        sharedPreferences = requireContext().getSharedPreferences("settings_preferences", Context.MODE_PRIVATE);

        return rootView;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        ProgressBar goalProgress = view.findViewById(R.id.goal_progress_bar);
        goalProgress.setIndeterminate(false); // Ensure the progress bar is in determinate mode
        updateProgressBar();

        Button goalWeightButton = view.findViewById(R.id.set_goal_button);
        goalWeightButton.setOnClickListener(v -> {
            updateProgressBar();
            if (database.doesGoalExist()) {
                goalWeightButton.setText(R.string.update_goal);
                showGoalWeightDialog();
            } else {
                goalWeightButton.setText(R.string.set_goal);
                showGoalWeightDialog();
            }
        });

        ExtendedFloatingActionButton addWeightFAB = view.findViewById(R.id.add_weight_button);
        addWeightFAB.setOnClickListener(v -> {
            showAddWeightDialog();
            checkGoalAndSendSms();
        });
    }

    void updateProgressBar() {
        ProgressBar goalProgress = requireView().findViewById(R.id.goal_progress_bar);
        TextView goalText = requireView().findViewById(R.id.goal_weight_text);
        TextView currentText = requireView().findViewById(R.id.current_weight_text);

        float currentGoal = database.getCurrentGoal();
        float currentWeight = database.getCurrentWeight();

        if (currentGoal > 0) {
            //If user is trying to lose weight
            if (currentGoal < currentWeight) {
                goalProgress.setMax((int) currentWeight);
                goalProgress.setProgress((int) currentGoal);
                //user trying to gain weight
            } else {
                goalProgress.setMax((int) currentGoal);
                goalProgress.setProgress((int) currentWeight);
            }
            goalText.setText(String.format(getString(R.string.goal_text), currentGoal));
            currentText.setText(String.format(getString(R.string.current_text), currentWeight));
            if (currentGoal == currentWeight) {
                resetProgressBar(goalProgress);
                checkGoalAndSendSms();
            }
        } else {
            goalText.setText(R.string.no_goal_set);
            currentText.setText(R.string.no_current_weight);
        }
    }

    private void resetProgressBar(ProgressBar goalProgress) {
        goalProgress.setMin(0);
        goalProgress.setProgress(0);
        goalProgress.setMax(100);
    }

    private void checkGoalAndSendSms() {
        boolean isSmsPermissionGranted = sharedPreferences.getBoolean("sms_permission", false);
        String phoneNumber = sharedPreferences.getString("user_phone_number", null);

        if (isSmsPermissionGranted && phoneNumber != null && (int) database.getCurrentWeight() == (int)database.getCurrentGoal()) {
            sendSms(phoneNumber, "Congratulations! You've achieved your goal weight of " + database.getCurrentGoal());
            sharedPreferences.edit().putBoolean("sms_permission", true).apply();
            sharedPreferences.edit().putString("user_phone_number", phoneNumber).apply();
        }
    }

    private void sendSms(String phoneNumber, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        Toast.makeText(getContext(), "SMS sent: " + message, Toast.LENGTH_SHORT).show();
    }

    private void showGoalWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        LayoutInflater inflater = getLayoutInflater();
        View addGoalView = inflater.inflate(R.layout.activity_user_goal_dialog, null);

        builder.setView(addGoalView);

        AlertDialog alertDialog = builder.create();
        alertDialog.show();

        Button closeGoalButton = addGoalView.findViewById(R.id.close_goal_button);
        closeGoalButton.setOnClickListener(view -> alertDialog.dismiss());

        Button submitGoalButton = addGoalView.findViewById(R.id.submit_goal_button);
        submitGoalButton.setOnClickListener(v -> {
            EditText inputGoal = addGoalView.findViewById(R.id.input_goal);
            String userInputGoal = inputGoal.getText().toString();

            if (userInputGoal.isEmpty()) {
                Toast.makeText(requireContext(), "You Must Enter a Goal", Toast.LENGTH_SHORT).show();
                alertDialog.dismiss();
            } else {
                float goal = Float.parseFloat(userInputGoal);
                if (!database.doesGoalExist()) {
                    database.addGoal(goal);
                } else {
                    long id = database.getCurrentGoalId();
                    boolean goalUpdated = database.updateGoal(id, goal);
                    if (goalUpdated) {
                        Toast.makeText(requireContext(), "Updated Goal: " + goal, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(requireContext(), "Failed to Update Goal", Toast.LENGTH_SHORT).show();
                    }
                }
                updateProgressBar();

                Toast.makeText(requireContext(), "Entered Goal: " + goal, Toast.LENGTH_SHORT).show();
            }
            alertDialog.dismiss();
        });
    }


    private void showAddWeightDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        LayoutInflater inflater = getLayoutInflater();
        View addWeightView = inflater.inflate(R.layout.activity_user_weight_dialog, null);

        builder.setView(addWeightView);

        AlertDialog alertDialog = builder.create();
        alertDialog.show();

        Button closeWeightButton = addWeightView.findViewById(R.id.close_weight_button);
        closeWeightButton.setOnClickListener(view -> alertDialog.dismiss());

        Button submitWeightButton = addWeightView.findViewById(R.id.submit_weight_button);
        submitWeightButton.setOnClickListener(v -> {
            EditText inputWeight = addWeightView.findViewById(R.id.input_weight);
            String userInputWeight = inputWeight.getText().toString();

            if (userInputWeight.isEmpty()) {
                Toast.makeText(requireContext(), "You Must Enter a Weight", Toast.LENGTH_SHORT).show();
                alertDialog.dismiss();
            } else {
                float weight = Float.parseFloat(userInputWeight);
                database.addWeight(weight);
                updateProgressBar();

                Toast.makeText(requireContext(), "Entered Weight: " + weight, Toast.LENGTH_SHORT).show();
            }
            alertDialog.dismiss();
        });
    }
}
