package com.zybooks.cs360_mugford_coty_weighttrackerapp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LoginActivity extends AppCompatActivity {
    private WeightTrackerDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        db = new WeightTrackerDatabase(this);

        EditText usernameText = findViewById(R.id.username_login);
        EditText passwordText = findViewById(R.id.password_login);
        Button loginButton = findViewById(R.id.login_button);
        Button createAccountButton = findViewById(R.id.create_account_button);
        CheckBox passLengthBox = findViewById(R.id.password_length_box);
        CheckBox passHasNumber = findViewById(R.id.password_has_number);
        CheckBox passHasSpecial = findViewById(R.id.password_has_special);

        passwordText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

                passLengthBox.setChecked(passwordText.getText().toString().length() >= 9);
                passHasNumber.setChecked(passwordContainsNumber(passwordText.getText().toString()));
                passHasSpecial.setChecked(passwordContainsSpecial(passwordText.getText().toString()));

                loginButton.setEnabled(passLengthBox.isChecked() && passHasNumber.isChecked() && passHasSpecial.isChecked());
                createAccountButton.setEnabled(passLengthBox.isChecked() && passHasNumber.isChecked() && passHasSpecial.isChecked());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        loginButton.setOnClickListener(view -> {
            String username = usernameText.getText().toString();
            String password = passwordText.getText().toString();

            if (checkUserExists(username)) {
                if (checkUserLoginInformation(username, password)) {
                    Toast.makeText(getApplicationContext(), "Welcome back, " + username + "!", Toast.LENGTH_LONG).show();
                    startActivity(new Intent(LoginActivity.this, MainActivity.class));
                    finish();
                } else {
                    Toast.makeText(getApplicationContext(), "Invalid password.", Toast.LENGTH_LONG).show();
                }
            } else {
                Toast.makeText(getApplicationContext(), "Invalid username, check spelling or create a new account.", Toast.LENGTH_LONG).show();
            }
        });

        createAccountButton.setOnClickListener(view -> {
            String username = usernameText.getText().toString();
            String password = passwordText.getText().toString();

            if (checkUserExists(username)) {
                Toast.makeText(getApplicationContext(), "User already exists, login or choose a different username.", Toast.LENGTH_LONG).show();
            } else {
                createUser(username, password);
                startActivity(new Intent(LoginActivity.this, MainActivity.class));
                finish();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.login_screen), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    //Checks if username and password match and is already in database
    private boolean checkUserLoginInformation(String username, String password) {
        Cursor cursor = db.getReadableDatabase().query("users", new String[] {"username", "password"},
                "username=? AND password=?", new String[]{username, password}, null, null, null);
        boolean userExistsPasswordCorrect = cursor.getCount() > 0;
        cursor.close();
        return userExistsPasswordCorrect;
    }

    private boolean checkUserExists(String username) {
        Cursor cursor = db.getReadableDatabase().query("users", new String[] {"username"},
                "username=?", new String[]{username}, null, null, null);
        boolean userExists = cursor.getCount() > 0;
        cursor.close();
        return userExists;
    }

    private void createUser(String username, String password) {
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        db.getWritableDatabase().insert("users", null, values);
    }

    //Checks if password contains a number
    private boolean passwordContainsNumber(String password) {
        for (char c : password.toCharArray()) {
            if (Character.isDigit(c)) {
                return true;
            }
        }
        return false;
    }

    //Checks if password contains a special character
    private boolean passwordContainsSpecial(String password) {
        for (char c : password.toCharArray()) {
            if (!Character.isLetterOrDigit(c)) {
                return true;
            }
        }
        return false;
    }
}