package com.zybooks.cs360_mugford_coty_weighttrackerapp;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerViewHolder> {
    private final List<WeightData> weightDataList;
    private final WeightTrackerDatabase database;

    public RecyclerAdapter(WeightTrackerDatabase database) {
        this.database = database;
        this.weightDataList = database.getAllWeights();
    }

    @NonNull
    @Override
    public RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View dataView = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_data_layout, parent, false);
        return new RecyclerViewHolder(dataView);
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder holder, int position) {
        WeightData weightData = weightDataList.get(position);

        holder.dateView.setText(weightData.getDate());
        holder.weightView.setText(holder.itemView.getContext().getString(R.string.weight_text, String.valueOf(weightData.getWeight())));

        holder.deleteButton.setOnClickListener(view -> {
            long id = weightData.getId();
            if (database.removeWeight(id)) {
                weightDataList.remove(position);
                notifyItemRemoved(position);
                notifyItemRangeChanged(position, getItemCount());
            }
        });
    }

    @Override
    public int getItemCount() {
        return weightDataList.size();
    }
}
