package com.zybooks.cs360_mugford_coty_weighttrackerapp;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class RecyclerViewHolder  extends RecyclerView.ViewHolder {
    public TextView dateView;
    public ImageView bodyImageView;
    public TextView weightView;
    public TextView borderView;
    public Button deleteButton;

    public RecyclerViewHolder(View dataView) {
        super(dataView);
        dateView = dataView.findViewById(R.id.date_view);
        bodyImageView = dataView.findViewById(R.id.body_image_icon);
        weightView = dataView.findViewById(R.id.user_weight);
        borderView = dataView.findViewById(R.id.border);
        deleteButton = dataView.findViewById(R.id.delete_row_button);
    }
}
