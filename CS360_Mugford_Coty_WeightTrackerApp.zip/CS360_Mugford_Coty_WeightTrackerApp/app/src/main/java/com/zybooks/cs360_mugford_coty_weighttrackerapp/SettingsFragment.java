package com.zybooks.cs360_mugford_coty_weighttrackerapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.Manifest;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.materialswitch.MaterialSwitch;

public class SettingsFragment extends Fragment {

    private static final String PREFERENCES_NAME = "settings_preferences";
    private static final String KEY_SMS_PERMISSIONS = "sms_permission";
    private static final String KEY_USER_PHONE_NUMBER = "user_phone_number";
    private static final String KEY_SMS_CLICKABLE = "sms_clickable";
    private ActivityResultLauncher<String> requestPermissionLauncher;
    private WeightTrackerDatabase database;
    private SharedPreferences sharedPreferences;
    private MaterialSwitch SmsPermissionSwitch;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_settings, container, false);
        database = new WeightTrackerDatabase(getContext());

        SmsPermissionSwitch = rootView.findViewById(R.id.sms_permissions);
        EditText userPhoneNumber = rootView.findViewById(R.id.enter_phone_number);
        Button submitPhoneNumber = rootView.findViewById(R.id.submit_phone_number_button);

        assert getActivity() != null;
        sharedPreferences = getActivity().getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE);

        MaterialSwitch unitConversionSwitch = rootView.findViewById(R.id.lbs_to_kgs_switch);
        boolean isMetric = sharedPreferences.getBoolean("unit_metric", false);
        unitConversionSwitch.setChecked(isMetric);

        unitConversionSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                database.convertWeight(true);
                database.convertGoal(true);
                //Store in sharedPreferences so that it stays between activities and logins
                sharedPreferences.edit().putBoolean("unit_metric", true).apply();
            } else {
                database.convertWeight(false);
                database.convertGoal(false);
                //Store in sharedPreferences so that it stays between activities and logins
                sharedPreferences.edit().putBoolean("unit_metric", false).apply();
            }

        });

        // Initialize the permission launcher
        requestPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
            //Saves the permissions and SMS switch click ability to shared preferences
            sharedPreferences.edit().putBoolean(KEY_SMS_PERMISSIONS, isGranted).apply();
            sharedPreferences.edit().putBoolean(KEY_SMS_CLICKABLE, false).apply();
            if (isGranted) {
                SmsPermissionSwitch.setClickable(false);
                userPhoneNumber.setClickable(true);
                submitPhoneNumber.setClickable(true);
            }
        });

        // Load the permissions and switch state from SharedPreferences
        boolean isSmsPermissionGranted = sharedPreferences.getBoolean(KEY_SMS_PERMISSIONS, false);
        boolean isSmsSwitchClickable = sharedPreferences.getBoolean(KEY_SMS_CLICKABLE, false);

        SmsPermissionSwitch.setChecked(isSmsPermissionGranted);
        SmsPermissionSwitch.setClickable(isSmsSwitchClickable);
        SmsPermissionSwitch.setChecked(isSmsPermissionGranted);
        if (isSmsPermissionGranted) {
            SmsPermissionSwitch.setClickable(false);
            userPhoneNumber.setClickable(true);
            submitPhoneNumber.setClickable(true);
        }

        // Request SMS permissions when the switch is toggled
        SmsPermissionSwitch.setOnClickListener(view -> {
            if (SmsPermissionSwitch.isChecked()) {
                requestSMSPermissions();
            } else {
                SmsPermissionSwitch.setChecked(false);
            }
        });

        submitPhoneNumber.setOnClickListener(view -> {
            String userInput = userPhoneNumber.getText().toString().trim();
            if (!userInput.isEmpty() && userInput.trim().length() == 10) {
                sharedPreferences.edit().putString(KEY_USER_PHONE_NUMBER, userInput).apply();
                sendSMS(userInput);
            } else {
                Toast.makeText(requireContext(), "Please enter a valid phone number", Toast.LENGTH_SHORT).show();
            }
        });

        return rootView;
    }

    private void requestSMSPermissions() {
        assert getActivity() != null;
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
        } else {
            // Disable the switch after permission is granted
            SmsPermissionSwitch.setClickable(false);
            EditText userPhoneNumber = requireView().findViewById(R.id.enter_phone_number);
            Button submitPhoneNumber = requireView().findViewById(R.id.submit_phone_number_button);
            userPhoneNumber.setClickable(true);
            submitPhoneNumber.setClickable(true);
            sharedPreferences.edit().putBoolean(KEY_SMS_PERMISSIONS, true).apply();
            sharedPreferences.edit().putBoolean(KEY_SMS_CLICKABLE, false).apply();
        }
    }

    private void sendSMS(String phoneNumber) {
        String message = "Your most recent weight was " + database.getCurrentWeight() +  " pounds. Nice work!";

        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }
}


