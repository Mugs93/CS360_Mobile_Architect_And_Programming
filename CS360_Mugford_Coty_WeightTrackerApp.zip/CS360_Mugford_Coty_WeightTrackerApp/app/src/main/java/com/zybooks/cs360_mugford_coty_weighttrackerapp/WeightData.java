package com.zybooks.cs360_mugford_coty_weighttrackerapp;

public class WeightData {
    private final long id;
    private final String date;
    private final float weight;

    public WeightData(long id, String date, float weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    public long getId() {

        return id;
    }

    public String getDate() {

        return date;
    }

    public float getWeight() {

        return weight;
    }
}
