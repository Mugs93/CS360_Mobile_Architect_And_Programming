package com.zybooks.cs360_mugford_coty_weighttrackerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class WeightTrackerDatabase extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weights.db";
    private static final int VERSION = 6;

    public WeightTrackerDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    //Goal Table Layout
    private static final class GoalTable {
        private static final String TABLE = "goals";
        private static final String COL_ID = "_id";
        private static final String COL_GOAL_DATE = "date";
        private static final String COL_GOAL_WEIGHT = "weight";
    }

    //Weight Table Layout
    private static final class WeightTable {
        private static final String TABLE = "weights";
        private static final String COL_ID = "_id";
        private static final String COL_DATE = "date";
        //Needed this because it would not update the current date because one was already entered for that date.
        //Now can add more than one date and it will update the currentWeight text.
        private static final String COL_TIMESTAMP = "timestamp";
        private static final String COL_WEIGHT = "weight";
    }

    //User Login Table Layout
    private static final class UserTable {
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME = "username";
        private static final String COL_PASSWORD = "password";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL("create table " + GoalTable.TABLE + " (" +
                GoalTable.COL_ID + " integer primary key autoincrement, " +
                GoalTable.COL_GOAL_DATE + " text, " +
                GoalTable.COL_GOAL_WEIGHT + " float) ");

        db.execSQL("create table " + WeightTable.TABLE + " (" +
                WeightTable.COL_ID + " integer primary key autoincrement, " +
                WeightTable.COL_DATE + " text, " +
                WeightTable.COL_TIMESTAMP + " integer, " + // New column
                WeightTable.COL_WEIGHT + " float) ");

        db.execSQL("create table " + UserTable.TABLE + " (" +
                UserTable.COL_ID + " integer primary key autoincrement, " +
                UserTable.COL_USERNAME + " text, " +
                UserTable.COL_PASSWORD + " text) ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + GoalTable.TABLE);
        db.execSQL("drop table if exists " + WeightTable.TABLE);
        db.execSQL("drop table if exists " + UserTable.TABLE);
        onCreate(db);
    }

    public float getCurrentWeight() {
        String sql = "SELECT " + WeightTable.COL_WEIGHT + " FROM " + WeightTable.TABLE +
                " ORDER BY " + WeightTable.COL_TIMESTAMP + " DESC LIMIT 1";
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery(sql, null);
        float recentWeight = -1;
        if (cursor.moveToFirst()) {
            recentWeight = cursor.getFloat(0);
        }
        cursor.close();
        return recentWeight;
    }

    public List<WeightData> getAllWeights() {
        List<WeightData> weights = new ArrayList<>();
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery("SELECT * FROM " + WeightTable.TABLE, null);
        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(WeightTable.COL_ID));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(WeightTable.COL_DATE));
                float weight = cursor.getFloat(cursor.getColumnIndexOrThrow(WeightTable.COL_WEIGHT));
                weights.add(new WeightData(id, date, weight));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return weights;
    }

    //CRUD Operations for Weight Table
    public void addWeight(float weight) {
        String currentDate = LocalDate.now().toString();
        long timestamp = System.currentTimeMillis();
        ContentValues values = new ContentValues();
        values.put(WeightTable.COL_DATE, currentDate);
        values.put(WeightTable.COL_TIMESTAMP, timestamp);
        values.put(WeightTable.COL_WEIGHT, weight);
        getWritableDatabase().insert(WeightTable.TABLE, null, values);
    }

    public boolean removeWeight(long id) {
        int rowsDeleted = this.getWritableDatabase().delete(WeightTable.TABLE, WeightTable.COL_ID + "=?",
                new String[]{String.valueOf(id)});
        return rowsDeleted > 0;
    }


    //CRUD operations for Goal
    public void addGoal(float goal) {
        LocalDate currentDate = LocalDate.now();
        ContentValues values = new ContentValues();
        values.put(GoalTable.COL_GOAL_DATE, String.valueOf(currentDate));
        values.put(GoalTable.COL_GOAL_WEIGHT, goal);
        getWritableDatabase().insert(GoalTable.TABLE, null, values);
    }

    public float getCurrentGoal() {
        String sql = "SELECT " + GoalTable.COL_GOAL_WEIGHT + " FROM " + GoalTable.TABLE +
                " ORDER BY " + GoalTable.COL_GOAL_DATE + " DESC LIMIT 1";
        Cursor cursor = getReadableDatabase().rawQuery(sql, null);
        float weight = -1;
        if (cursor.moveToFirst()) {
            weight = cursor.getFloat(0);
        }
        cursor.close();
        return weight;
    }


    public long getCurrentGoalId() {
        String sql = "SELECT " + GoalTable.COL_ID + " FROM " + GoalTable.TABLE +
                " ORDER BY " + GoalTable.COL_GOAL_DATE + " DESC LIMIT 1";
        Cursor cursor = getReadableDatabase().rawQuery(sql, null);
        long id = -1;

        if (cursor.moveToFirst()) {
            id = cursor.getLong(0);
        }
        cursor.close();
        return id;
    }

    public boolean updateGoal(long id, float weight) {
        ContentValues values = new ContentValues();
        values.put(GoalTable.COL_GOAL_WEIGHT, weight);

        int rowsUpdated = getWritableDatabase().update(GoalTable.TABLE, values, GoalTable.COL_ID + " = ?",
                new String[] { Long.toString(id) });
        return rowsUpdated > 0;
    }

    public boolean doesGoalExist() {
        Cursor cursor = getReadableDatabase().query(GoalTable.TABLE, new String[]{GoalTable.COL_GOAL_WEIGHT},
                null, null, null, null, null
        );
        boolean goalExists = cursor.getCount() > 0;
        cursor.close();
        return goalExists;
    }

    public void convertWeight(boolean convertToMetric) {
        List<WeightData> weights = getAllWeights();
        SQLiteDatabase database = getWritableDatabase();
        ContentValues contentValues = new ContentValues();

        for (WeightData weightData : weights) {
            float convertedWeight;
            if (convertToMetric) {
                convertedWeight = convertToMetrics(weightData.getWeight());
            } else {
                convertedWeight = convertToImperial(weightData.getWeight());
            }

            contentValues.put(WeightTable.COL_WEIGHT, convertedWeight);

            database.update(WeightTable.TABLE, contentValues, WeightTable.COL_ID + " =?",
                    new String[]{String.valueOf(weightData.getId())});
        }
    }

    public void convertGoal(boolean convertToMetric) {
        long currentGoalID = getCurrentGoalId();
        ContentValues contentValues = new ContentValues();
        float currentGoal = getCurrentGoal();
        float convertCurrentGoal;
        if (convertToMetric) {
            convertCurrentGoal = convertToMetrics(currentGoal);
        } else {
            convertCurrentGoal = convertToImperial(currentGoal);
        }
        contentValues.put(GoalTable.COL_GOAL_WEIGHT, convertCurrentGoal);
        getWritableDatabase().update(GoalTable.TABLE, contentValues, GoalTable.COL_ID + " =?",
                new String[]{String.valueOf(currentGoalID)});
    }

    public float convertToMetrics(float pounds) {
        return (float) (pounds / 2.2046);
    }

    public float convertToImperial(float kilos) {
        return (float) (kilos * 2.2046);
    }
}
